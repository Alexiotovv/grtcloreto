<div class="navbar navbar-dark bg-info">
    <?php if(Route::has('login')): ?>
        <div class="nav-item">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('home')); ?>" class="navbar-brand">Home</a>
                 
                <form action="login" method="post" class="navbar-brand ">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-danger">Logout</button>
                </form>

            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="navbar-brand">Login</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="navbar-brand ">Register</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalaria\resources\views/partials/navbar.blade.php ENDPATH**/ ?>