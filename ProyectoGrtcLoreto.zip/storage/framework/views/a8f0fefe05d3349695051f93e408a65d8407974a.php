
<?php $__env->startSection('aditional_link'); ?>
	<link rel="stylesheet" type="text/css" href="../../../assets/vendors/css/tables/datatable/dataTables.bootstrap5.min.css">
	<link rel="stylesheet" type="text/css" href="../../../assets/vendors/css/tables/datatable/responsive.bootstrap5.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

	<div class="content-body">
		<!-- Ajax Sourced Server-side -->
		<section >
			<div class="row">
				<div class="col-12">
					<div class="card" style="text-align: center">
						<div class="card-header border-bottom">
							<h4 class="card-title">FICHA FAMILIAR</h4>
						</div>
						<div class="">
							<table class="table table-flush" id="listausuarios">
								<thead class="thead-light">
									<tr>
										<th>Id</th>
										<th>Acciones</th>
										<th>Nombre</th>
									</tr>
								</thead>
								<tbody>
									
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</section>

		<!--/ Ajax Sourced Server-side -->

	</div>
	<?php $__env->startSection('code_js'); ?>
		<script>
			$("#listausuarios").DataTable({
				"ajax":"datosventas",
				"method":"GET",
				"columns":[
					{data:"numDoc"},
					{data:"direccion"},
					{data:"provincia"},
				],
				dom: 'Bfrtip',
			});
		</script>
	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalariaJunin\resources\views/listarventa.blade.php ENDPATH**/ ?>