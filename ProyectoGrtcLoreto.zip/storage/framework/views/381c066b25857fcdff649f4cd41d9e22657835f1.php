
<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="page-content">
        <div class="col-sm-12">
            <button type="button" class="btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#exampleSmallModal1">
                <i class="lni lni-plus"></i>Nuevo Registro Trabajador Comunitario de Salud
            </button>
        </div>
        <br>

        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example2"  class="table table-striped table-bordered" >
                        <thead>
                            <tr>
                                <th style="text-align: center;">Id</th>
                                <th style="text-align: center;">DNI</th>
                                <th style="text-align: center;">Nombre TCS</th>                              
                                <th style="text-align: center;">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $lista_tcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tcs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>                    
                                    <td><?php echo e($tcs->idtcs); ?> <input type="hidden" id="hid<?php echo e($tcs->idtcs); ?>" value="<?php echo e($tcs->idtcs); ?>" ></td>
                                    <td><?php echo e($tcs->dni_tcs); ?> <select hidden id="hdni_tcs<?php echo e($tcs->dni_tcs); ?>"><option value="<?php echo e($tcs->dni_tcs); ?>"><?php echo e($tcs->dni_tcs); ?></option> </select></td>
                                    <td><?php echo e($tcs->nombre_tcs); ?> <select hidden id="hnombre_tcs<?php echo e($tcs->nombre_tcs); ?>"><option value="<?php echo e($tcs->nombre_tcs); ?>"><?php echo e($tcs->nombre_tcs); ?></option></select></td>
                                    <td style="vertical-align: middle;">
                                        <button class="btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#exampleSmallModal2" onclick="">
                                        <i class="lni lni-pencil"></i>
                                        </button>
                                        <button class="btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#exampleSmallModal3"  onclick="">
                                            <i class="lni lni-cross-circle"></i>
                                        </button>
                                    </td>
                                    </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        
        <form  action="<?php echo e(route('GrabarTCS')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal fade" id="exampleSmallModal1" data-bs-target="#exampleSamllModal1" aria-hidden="true">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6 class="modal-title">Registro de Asistencia de Trabajadores Comunitarios de Salud</h6>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="modal-body">
                                <div class="row">
                                    
                                    <label for="">DNI</label>
                                    <input name="dni" id="dni" type="text" class="form-control" value="-">

                                    <label for="">Fecha Capacitación</label>
                                    <input name="nombre" id="nombre" type="date" class="form-control" >
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn-sm btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                            <button type="submit" class="btn-sm btn-warning">Guardar</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>



        

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script_select2'); ?>
<script>
    $('.single-select').select2({
        theme: 'bootstrap4',
        width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
        placeholder: $(this).data('placeholder'),
        allowClear: Boolean($(this).data('allow-clear')),
    });
    $('.multiple-select').select2({
        theme: 'bootstrap4',
        width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
        placeholder: $(this).data('placeholder'),
        allowClear: Boolean($(this).data('allow-clear')),
    });

    var fecha = new Date();
    document.getElementById("Fecha").value = fecha.toJSON().slice(0,10);
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('../layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalaria\resources\views//tcs/tcs_crud.blade.php ENDPATH**/ ?>