


<?php $__env->startSection('content'); ?>
    
    <label for="">Seleccione Items Ficha Familiar</label>
    <form id="frmItemFichaFamiliar">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">
                <select name="Item" id="Item" class="select2">
                    <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->item); ?>"><?php echo e($item->item); ?></option>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-outline-danger" name="btnAgregar" id="btnAgregar"><i data-feather='plus'></i>Agregar</button>
            </div>
        </div>
    </form>

    <div class="card">
        <div class="card-header border-bottom" style="align-self: center;">
            <h5 class="card-title">Items Seleccionados</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6" style="align-self: center;">
                    <div class="card-datatable">
                        <table id="DTItems" class="table table-responsive">
                            <thead>
                                <tr>
                                    <th style="font-size: 10px;">id</th>
                                    <th style="font-size: 10px;">NombreItem</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>

    <script>
        $(document).on('select2:open', () => {
            document.querySelector('.select2-search__field').focus();
        });
    </script>
    <script src="../../../src/js/scripts/pages_app/cuadro_resumen.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalariaJunin\resources\views/otrasopciones.blade.php ENDPATH**/ ?>