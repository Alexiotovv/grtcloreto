

<?php $__env->startSection('footer'); ?>
           <h1>Soy el footer</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProyectosLaravel\DashboardCovid\resources\views/footer.blade.php ENDPATH**/ ?>