

<?php $__env->startSection('content'); ?>
    
   <!--start page wrapper -->
  
		<div class="page-wrapper">
			<div class="page-content">
				<h3 style="text-align: center">BIENVENIDO</h3>
				
			</div>
		</div>
		<!--end page wrapper -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalaria\resources\views/home.blade.php ENDPATH**/ ?>