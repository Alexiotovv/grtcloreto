<?php $__env->startSection('content'); ?>
    <div class="content-body">


		<section class="bs-validation">
			<div class="row">
				<!-- Bootstrap Validation -->
				<div class="col-md-6 col-md-12">
					<div class="card">
						<div class="card-header">
							<h4 class="card-title">Registro de Usuario</h4>
						</div>
						<div class="card-body">
							
							<form id="formRegistro" action="<?php echo e(url('register')); ?>" method="POST"><?php echo csrf_field(); ?>
								<div class="form-group">
									<label class="form-label" for="">NombreUsuario</label>
									<input type="text" id="name" class="form-control" name="name" placeholder="Name" aria-label="Name" aria-describedby="basic-addon-name" required />
									<p id="estadousuario" style="color: red"></p> 
								</div>
								<div class="form-group">
									<label class="form-label" for="">Correo</label>
									<input type="email" id="email" name="email" class="form-control" placeholder="john.doe@email.com" aria-label="john.doe@email.com" required />
									<p id="estadoemail" style="color: red"></p>
								</div>
								<div class="form-group">
									<label class="form-label" for="">Contraseña</label>
									<input type="password" id="password" name="password" class="form-control" placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;" required />
								</div>
								<div class="row">
									<div class="col-12">
										<button type="submit" class="btn btn-primary btnRegistrar">Registrar</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
				<!-- /Bootstrap Validation -->
			</div>
		</section>

	</div>
</div>
<?php $__env->stopSection(); ?>


<script>
		$("#name").keyup(function(){
			var serializedData = $("#formRegistro").serialize();
			$.ajax({
				type: "POST",
				url: "verificanombre",
				data: serializedData,
				dataType: "json",
				success: function (response) {
					if (response['estado']=='Disponible') {
						$("#estadousuario").hide();
						// $("#estadousuario").text('Disponible');
					}else{
						$("#estadousuario").show();
						$("#estadousuario").text('No Disponible');
					}
				}
			});
		});

		$("#email").keyup(function(){
			var serializedData = $("#formRegistro").serialize();
			$.ajax({
				type: "POST",
				url: "verificaemail",
				data: serializedData,
				dataType: "json",
				success: function (response) {
					if (response['estado']=='Disponible') {
						$("#estadoemail").hide();
						// $("#estadousuario").text('Disponible');
					}else{
						$("#estadoemail").show();
						$("#estadoemail").text('No Disponible');
					}
				}
			});
		});


	$(document).on("click",".btnRegistrar",function(e){
		e.preventDefault();
		var serializedData = $("#formRegistro").serialize();
		if (($("#estadousuario").val()=='No Disponible') ||($("#estadoemail").val()=='No Disponible')) {
			
		}else{
			$.ajax({
				type: "POST",
				url: "register",
				data: serializedData,
				dataType: "json",
				success: function (response) {
					round_success_noti();
				}
			});
		// $("#GuardadoModal").modal('show');
		}
		
	});

</script>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalariaJunin\resources\views/register.blade.php ENDPATH**/ ?>