

<?php $__env->startSection('content'); ?>
		
	<h3 style="text-align: center">BIENVENIDO</h3>
		
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoResultadosLab\resources\views/home.blade.php ENDPATH**/ ?>