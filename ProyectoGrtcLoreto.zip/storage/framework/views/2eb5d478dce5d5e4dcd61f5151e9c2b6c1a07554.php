

<?php $__env->startSection('content'); ?>
<!--start page wrapper -->
<div class="page-wrapper">
	<div class="page-content">
		<div class="row">
			<div class="col-12 col-lg-12">
				<!--<h6 class="mb-0 text-uppercase">Casos Covid</h6>-->
				<hr/>
				<form action=""><?php echo csrf_field(); ?>
					<div class="card">
					<div class="card-body">
						<div class="card radius-10 bg-primary bg-gradient">
							<div class="card-body">
								<div class="d-flex align-items-center">
										<h4 class="my-1 text-white">TOTAL CASOS 2021-2022/</h4>
										<h4 class="my-1" style="color:yellow"> PRUEBAS PCR, RÁPIDAS Y ANTÍGENOS </h4>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<select name="period" id="period" class="single-select">
									<option value="todo">todo</option>
									<option value="2020">2020</option>
									<option value="2021">2021</option>
									<option value="2022">2022</option>
								</select>
							</div>
							<div class="col-sm-6">
								<input type="submit" class="btn btn-success" value="Filtrar">
							</div>
						</div>
					
						<div class="table-responsive">
							<table id="example2" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>PROVINCIA</th>
										<th>DISTRITO</th>
										
										<?php if($period=='todo'): ?>
											<th>(+) 2020</th>
											<th>(-) 2020</th>
											<th>(Σ) 2020</th>
											<th>(+) 2021</th>
											<th>(-) 2021</th>
											<th>(Σ) 2021</th>
											<th>(+) 2022</th>
											<th>(-) 2022</th>
											<th>(Σ) 2022</th>
										<?php endif; ?>

										<?php if($period=='2020'): ?>
											<th>(+) 2020</th>
											<th>(-) 2020</th>
											<th>(Σ) 2020</th>
										<?php endif; ?>
										
										<?php if($period=='2021'): ?>
											<th>(+) 2021</th>
											<th>(-) 2021</th>
											<th>(Σ) 2021</th>
										<?php endif; ?>

										<?php if($period=='2022'): ?>
											<th>(+) 2022</th>
											<th>(-) 2022</th>
											<th>(Σ) 2022</th>
										<?php endif; ?>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $casos_covid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($cc->Provincia); ?></td>
											<td><?php echo e($cc->Distrito); ?></td>
											
											<?php if($period=='todo'): ?>
												<td><?php echo e($cc->Positivos_2020); ?></td>
												<td><?php echo e($cc->Negativos_2020); ?></td>
												<td><?php echo e($cc->Total_2020); ?></td>
												<td><?php echo e($cc->Positivos_2021); ?></td>
												<td><?php echo e($cc->Negativos_2021); ?></td>
												<td><?php echo e($cc->Total_2021); ?></td>
												<td><?php echo e($cc->Positivos_2022); ?></td>
												<td><?php echo e($cc->Negativos_2022); ?></td>
												<td><?php echo e($cc->Total_2022); ?></td>
											<?php endif; ?>

											<?php if($period=='2020'): ?>
												<td><?php echo e($cc->Positivos_2020); ?></td>
												<td><?php echo e($cc->Negativos_2020); ?></td>
												<td><?php echo e($cc->Total_2020); ?></td>
											<?php endif; ?>
											<?php if($period=='2021'): ?>
												<td><?php echo e($cc->Positivos_2021); ?></td>
												<td><?php echo e($cc->Negativos_2021); ?></td>
												<td><?php echo e($cc->Total_2021); ?></td>
											<?php endif; ?>
											<?php if($period=='2022'): ?>
												<td><?php echo e($cc->Positivos_2022); ?></td>
												<td><?php echo e($cc->Negativos_2022); ?></td>
												<td><?php echo e($cc->Total_2022); ?></td>
											<?php endif; ?>
											
										
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>

						<div class="row row-cols-1 row-cols-md-2 row-cols-xl-4">
							<div class="col">
								<button type="button" class="btn btn-danger">
									POSITIVOS:
									<span class="badge">15,5222.00</span>
								</button>
							</div>
							
							<div class="col">
								<button type="button" class="btn btn-success">
									NEGATIVOS:
									<span class="badge">15,5222.00</span>
								</button>
							</div>

							<div class="col">
								<button type="button" class="btn btn-dark">
									TOTAL:
									<span class="badge">15,5222.00</span>
								</button>
							</div>

							<div class="col">
								<button type="button" class="btn btn-warning">
									Los Casos positivos del Total de Pacientes:
									<span class="badge bg-dark">28.66 %</span>
								</button>
							</div>
						</div>

						



					</div>
				</form>
				</div>
			

            </div>
        </div>
    </div>
</div>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\DashboardCovid\resources\views/consolidadocasos.blade.php ENDPATH**/ ?>