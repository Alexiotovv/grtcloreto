

<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-header border-bottom">
            <h5 class="card-title">FICHA DE EVALUACIÓN DE LOCALIDAD CON MAPEO ENTOMOLÓGICO</h5>
            <!-- Button trigger modal -->
            <button class="btn btn-primary" data-toggle="modal" id="btnNuevoMapeoEnto"><i
                    data-feather='plus'></i>
                Nuevo
            </button>
            <!-- Modal -->
        </div>
        <div class="card-body">
            <table id="DTListaMapeoEnto" class="table table-responsive">
                <thead>
                    <tr>
                        <td>Id</td>
                        <td>Accion</td> 
                        <td>Provincia</td>
                        <td>Distrito</td>
                        <td>Red</td>
                        <td>MicroRed</td>
                        <td>Localidad</td>
                        <td>Usuario</td>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>

    </div>

    
    <div class="modal-size-lg d-inline-block">
        <div class="modal fade text-left" id="ModalListaIndicePicadura" tabindex="-1" role="dialog"
            aria-labelledby="myModalLabel16" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Lista Índice de Picadura</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <button class="btn btn-primary" id="btnNuevoIndicePicadura">
                                    <i data-feather='plus'></i>Nuevo
                                </button>
                            </div>
                        </div>
                        <table class="table table-responsive" id="DTListaIndicePicadura">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Acción</th>
                                    <th>Fecha</th>
                                    <th>Índice P. Hora-Hombre</th>
                                    <th>Índice P. Hora-Noche</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    


    <form id="formMapeoEnto">
        <?php echo csrf_field(); ?>
        <div class="modal-size-lg d-inline-block">
            <div class="modal fade text-left" id="ModalMapeoEnto" tabindex="-1" role="dialog"
                aria-labelledby="myModalLabel16" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="EtiquetaMapeoEnto">-</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="col-lg-12">    
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label for="">ID</label>
                                        <input type="text" class="form-control form-control-md" name="IdMapeoEnto" 
                                        id="IdMapeoEnto" readonly>
                                    </div>
                                    
                                    <div class="col-lg-4">
                                        <label for="">PROVINCIA</label>
                                        <select name="Provincia" id="Provincia" class="form-control form-control-md"
                                            readonly>
                                            <?php $__currentLoopData = $prov; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($prov->id); ?>"><?php echo e($prov->nombre_prov); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-lg-6">
                                        <label for="">DISTRITO</label>
                                        <select name="Distrito" id="Distrito" class="select2 form-control"
                                            onchange="ObtieneRegiones('Distrito');">
                                            <?php $__currentLoopData = $dist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dist->id); ?>">
                                                    <?php echo e($dist->codigo); ?>-<?php echo e($dist->nombre_dist); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="">RED</label>
                                        
                                        <select name="Idred" id="Idred" class="form-control form-control-md"
                                        readonly>
                                            <?php $__currentLoopData = $red; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($red->id); ?>">
                                                    <?php echo e($red->codigo); ?>-<?php echo e($red->nombre_red); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="">MICRORED</label>
                                        
                                        <select name="Idmicrored" id="Idmicrored" onchange="ObtieneRed('Idmicrored');" class="select2 form-control-md">
                                            <?php $__currentLoopData = $microred; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $microred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($microred->id); ?>">
                                                    <?php echo e($microred->codigo); ?>-<?php echo e($microred->nombre_microred); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                            
                                    <div class="col-lg-4">
                                        <label for="">LOCALIDAD</label>
                                        <select name="Localidad" id="Localidad" class="select2" >
                                            <?php $__currentLoopData = $localidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($loc->id); ?>"><?php echo e($loc->nombre_localidad); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success" id="btnGuardaMapeoEnto">Guardar</button>
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Cerrar</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </form>

    <form id="formIndicePicadura">
        <?php echo csrf_field(); ?>
        <div class="modal-size-sm d-inline-block">
            <div class="modal fade text-left" id="ModalIndicePicadura" tabindex="-1" role="dialog"
                aria-labelledby="myModalLabel16" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="EtiquetaIndicePicadura">-</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="col-sm-12">    
                                <div class="row">
                                    <div class="col-sm-12">
                                        <label for="">ID</label>
                                        <input type="text" class="form-control form-control-sm" name="IdIndicePicadura" 
                                        id="IdIndicePicadura" readonly>
                                        <input type="text" class="form-control form-control-sm" name="IdIndicePicaduraMapeoEnto" 
                                        id="IdIndicePicaduraMapeoEnto" 
                                        hidden>
                                    </div>
                                    
                                    <div class="col-sm-12">
                                        <label for="">FECHA</label>
                                        <input type="date" class="form-control form-control-sm" name="fecha" 
                                        id="fecha">
                                    </div>
                                    <div class="col-sm-12">
                                        <label for="">ÍNDICE HORA-HOMBRE</label>
                                        <input type="text" class="form-control form-control-sm" name="indicehombrehora" 
                                        id="indicehombrehora">
                                    </div>
                                    <div class="col-sm-12">
                                        <label for="">ÍNDICE HORA-NOCHE</label>
                                        <input type="text" class="form-control form-control-sm" name="indicehombrenoche" 
                                        id="indicehombrenoche">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success" id="btnGuardaIndicePicadura">Guardar</button>
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Cerrar</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_js'); ?>
    <script>
        $(document).on('select2:open', () => {
            document.querySelector('.select2-search__field').focus();
        });
    </script>    
    
    <script src="../../../src/js/scripts/pages_app/crud.js"></script>
    <script src="../../../src/js/scripts/pages_app/mapeoento.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalariaJunin\resources\views/Mapeoento.blade.php ENDPATH**/ ?>