

<?php $__env->startSection('content'); ?>

<h5>1. Cómo Registrar una Ficha Familiar</h5>
    <iframe width="720" height="481" src="https://www.youtube.com/embed/HhAG-US8wjk" title="1.PlanEliminaciondeLaMalaria-RegistroFichaFamiliar" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
    </iframe>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalariaJunin\resources\views/guia_registro.blade.php ENDPATH**/ ?>