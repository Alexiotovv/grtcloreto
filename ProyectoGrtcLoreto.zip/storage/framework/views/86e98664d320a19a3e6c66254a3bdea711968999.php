

<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-header border-bottom">
            <h5 class="card-title">FICHA DE EVALUACIÓN DE VIVIENDAS CON RRI</h5>
            <!-- Button trigger modal -->
            <button class="btn btn-primary" data-toggle="modal" id="btnNuevoRegistroRRI"><i
                    data-feather='plus'></i>
                Nuevo
            </button>
            <!-- Modal -->
        </div>
        <div class="card-body">
            <table id="DTListaViviendasRRI" class="table table-responsive">
                <thead>
                    <tr>
                        <td>Id</td>
                        <td>Accion</td> 
                        <td>Provincia</td>
                        <td>Distrito</td>
                        <td>Red</td>
                        <td>MicroRed</td>
                        <td>Localidad</td>
                        <td>Usuario</td>

                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>

    </div>

    
    <div class="modal-size-lg d-inline-block">
        <div class="modal fade text-left" id="ModalListaViviendasRociadas" tabindex="-1" role="dialog"
            aria-labelledby="myModalLabel16" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Lista Viviendas Rociadas</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <button class="btn btn-primary" id="btnNuevoViviendaRociada">
                                    <i data-feather='plus'></i>Nuevo
                                </button>
                            </div>
                        </div>
                        <table class="table table-responsive" id="DTListaViviendasRociadas">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Acción</th>
                                    <th>Número V.Rociadas</th>
                                    <th>Fecha Primer Ciclo</th>
                                    <th>Fecha Segundo Ciclo</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    
    <div class="modal-size-xl d-inline-block">
        <div class="modal fade text-left" id="ModalListaCensoMosquitero" tabindex="-1" role="dialog"
            aria-labelledby="myModalLabel16" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Lista Censo Mosquitero</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <button class="btn btn-primary" id="btnNuevoCensoMosquitero">
                                    <i data-feather='plus'></i>Nuevo
                                </button>
                            </div>
                        </div>

                        <table class="table table-responsive" id="DTListaCensoMosquitero">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Acción</th>
                                    <th>Numero Mosquitero</th>
                                    <th>Cantidad Usan</th>
                                    <th>Tamano</th>
                                    <th>Buen Estado</th>
                                    <th>Impregnado</th>
                                    <th>Fecha Impregnacion</th>
                                    <th>Insecticida Usado</th>
                                    <th>Material</th>
                                    <th>Color</th>
                                    <th>Jefe Hogar</th>
                                    <th>Dni Jefe Hogar</th>
                                    <th>Responsable Censo</th>
                                    <th>Dni Responsable Censo</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

    <form id="formViviendasRRI">
        <?php echo csrf_field(); ?>
        <div class="modal-size-lg d-inline-block">
            <div class="modal fade text-left" id="ModalViviendasRRI" tabindex="-1" role="dialog"
                aria-labelledby="myModalLabel16" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="EtiquetaViviendasRRI">-</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="col-lg-12">    
                                <div class="row">
                                    <div class="col-lg-2">
                                        <label for="">ID</label>
                                        <input type="text" class="form-control form-control-md" name="IdViviendasRRI" 
                                        id="IdViviendasRRI" readonly>
                                    </div>
                                    
                                    <div class="col-lg-4">
                                        <label for="">PROVINCIA</label>
                                        <select name="Provincia" id="Provincia" class="form-control form-control-md"
                                            readonly>
                                            <?php $__currentLoopData = $prov; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($prov->id); ?>"><?php echo e($prov->nombre_prov); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-lg-6">
                                        <label for="">DISTRITO</label>
                                        <select name="Distrito" id="Distrito" class="select2 form-control"
                                            onchange="ObtieneRegiones('Distrito');">
                                            <?php $__currentLoopData = $dist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dist->id); ?>">
                                                    <?php echo e($dist->codigo); ?>-<?php echo e($dist->nombre_dist); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="">RED</label>
                                        
                                        <select name="Idred" id="Idred" class="form-control form-control-md"
                                        readonly>
                                            <?php $__currentLoopData = $red; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($red->id); ?>">
                                                    <?php echo e($red->codigo); ?>-<?php echo e($red->nombre_red); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-lg-4">
                                        <label for="">MICRORED</label>
                                        
                                        <select name="Idmicrored" id="Idmicrored" onchange="ObtieneRed('Idmicrored');" class="select2 form-control-md">
                                            <?php $__currentLoopData = $microred; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $microred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($microred->id); ?>">
                                                    <?php echo e($microred->codigo); ?>-<?php echo e($microred->nombre_microred); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                            
                                    <div class="col-lg-4">
                                        <label for="">LOCALIDAD</label>
                                        <input type="text" name="Localidad" id="Localidad" class="form-control form-control-md">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success" id="btnGuardaViviendaRRI">Guardar</button>
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Cerrar</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </form>

    <form id="formViviendasRociadas">
        <?php echo csrf_field(); ?>
        <div class="modal-size-sm d-inline-block">
            <div class="modal fade text-left" id="ModalViviendasRociadas" tabindex="-1" role="dialog"
                aria-labelledby="myModalLabel16" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="EtiquetaViviendasRociadas">-</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="col-sm-12">    
                                <div class="row">
                                    <div class="col-sm-12">
                                        <label for="">ID</label>
                                        <input type="text" class="form-control form-control-sm" name="IdViviendasRociadas" 
                                        id="IdViviendasRociadas" readonly>
                                        <input type="text" class="form-control form-control-sm" name="IdViviendasRociadasIRR" 
                                        id="IdViviendasRociadasIRR" 
                                        hidden>
                                    </div>
                                    
                                    <div class="col-sm-12">
                                        <label for="">NÚMERO VIVIENDAS ROCIADAS</label>
                                        <input type="number" class="form-control form-control-sm" name="NumeroViviendasRociadas" 
                                        id="NumeroViviendasRociadas">
                                    </div>
                                    <div class="col-sm-12">
                                        <label for="">FECHA PRIMER CICLO</label>
                                        <input type="date" class="form-control form-control-sm" name="FechaPrimerCiclo" 
                                        id="FechaPrimerCiclo">
                                    </div>
                                    <div class="col-sm-12">
                                        <label for="">FECHA SEGUNDO CICLO</label>
                                        <input type="date" class="form-control form-control-sm" name="FechaSegundoCiclo" 
                                        id="FechaSegundoCiclo">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-success" id="btnGuardaViviendaRociada">Guardar</button>
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Cerrar</button>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </form>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra_js'); ?>
    <script>
        $(document).on('select2:open', () => {
            document.querySelector('.select2-search__field').focus();
        });
    </script>    
    
    <script src="../../../src/js/scripts/pages_app/crud.js"></script>
    <script src="../../../src/js/scripts/pages_app/viviendasrri.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalariaJunin\resources\views/ViviendasRRI.blade.php ENDPATH**/ ?>