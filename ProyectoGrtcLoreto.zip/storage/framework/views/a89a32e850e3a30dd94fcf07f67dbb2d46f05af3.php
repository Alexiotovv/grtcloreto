


<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">CARACTERÍSTICAS DE LOS MIEMBROS DE LA FAMILIA</h5>
            <div class="row">               
                <div class="col-md-3">
                    <label for="Item">Seleccione Item</label>
                    <select name="Item" id="Item" class="select2">
                        <option value="EtniaRaza">EtniaRaza</option>
                        <option value="IdiomaPredominante">IdiomaPredominante</option>
                        <option value="Religion">Religion</option>
                        <option value="GradoInstruccion">GradoInstruccion</option>
                        <option value="EstadoCivil">EstadoCivil</option>
                        <option value="Ocupacion">Ocupacion</option>
                        <option value="SeguroSalud">SeguroSalud</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="">Seleccione Localidades (Máximo 10)</label>
                    <select name="Localidades2[]" id="Localidades2" class="select2" multiple="multiple">
                        <?php $__currentLoopData = $localidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->Localidad); ?>"><?php echo e($item->Localidad); ?></option>    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>                
                </div>

                <div class="col-md-3">
                    <br>
                    <button class="btn btn-danger" id="FiltrarDinamico"><i data-feather='search'></i>Filtrar</button>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="card-datatable">
                        <table id="DTFF_PorItem" class="table table-responsive">
                            <thead>
                                <tr>
                                    <th style="font-size: 10px;">NOMBRE DEL ITEM</th>
                                    <th style="font-size: 10px;">TOTAL</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-6">

                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <label for="">Seleccione Localidades (Máximo 10)</label>
            <form id="frmLocalidades">
                
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <select name="Localidades[]" id="Localidades" class="select2" multiple="multiple">
                            <?php $__currentLoopData = $localidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->Localidad); ?>"><?php echo e($item->Localidad); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>                
                    </div>
                    <div class="col-md-3">
                        <button class="btn btn-outline-danger" name="btnEtapaVida" id="btnEtapaVida"><i data-feather='search'></i>Filtrar</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-header border-bottom" style="align-self: center;">
            <h5 class="card-title">POBLACIÓN POR ETAPA DE VIDA</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6" style="align-self: center;">
                    <div class="card-datatable">
                        <table id="DTEtapaVida" class="table table-responsive">
                            <thead>
                                <tr>
                                    <th style="font-size: 10px;">EtapaVida</th>
                                    <th style="font-size: 10px;">Masculino</th>
                                    <th style="font-size: 10px;">Femenino</th>
                                    <th style="font-size: 10px;">Total</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
        
                <div class="col-md-6">
                    <div id="myChartEtapaVida">
                        
                    </div>	
                </div>
            </div>
        </div>

    </div>

    <div class="card">
        <div class="card-header border-bottom" style="align-self: center;">
            <h5 class="card-title">T.RESIDENCIA/V.MULTIFAMILIAR</h5>
        </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6" style="align-self: center;">
                        <div class="card-datatable">
                            <table id="DTFF_TiempRes" class="table table-responsive">
                                <thead>
                                    <tr>
                                        <th style="font-size: 10px;">T.RESIDENCIA</th>
                                        <th style="font-size: 10px;">MULTIFAMILIAR(SI)</th>
                                        <th style="font-size: 10px;">MULTIFAMILIAR(NO)</th>
                                        <th style="font-size: 10px;">TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                </div>
                <div class="col-md-6">
                    <div id="myChartFF_TiempRes">
                        
                    </div>	
                </div>
            </div>
        </div>

    </div>

    <div class="card">
        <div class="card-header border-bottom" style="align-self: center;">
            <h5 class="card-title">TIEMPO AL ESTABLECIMIENTO DE SALUD MÁS CERCANO</h5>
        </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6" style="align-self: center;">
                        <div class="card-datatable">
                            <table id="DTFF_TiempoEESSCercano" class="table table-responsive">
                                <thead>
                                    <tr>
                                        <th style="font-size: 10px;">RANGO MINUTOS</th>
                                        <th style="font-size: 10px;">TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                </div>
                <div class="col-md-6">
                    <div id="myChartFF_TiempEESSCercano">
                        
                    </div>	
                </div>
            </div>
        </div>

    </div>

    <div class="card">
        <div class="card-header border-bottom" style="align-self: center;">
            <h5 class="card-title">MEDIOS DE TRANSPORTES USADOS</h5>
        </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6" style="align-self: center;">
                        <div class="card-datatable">
                            <table id="DTFF_MedioTransporte" class="table table-responsive">
                                <thead>
                                    <tr>
                                        <th style="font-size: 10px;">MEDIO DE TRANSPORTE</th>
                                        <th style="font-size: 10px;">TOTAL</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                </div>
                <div class="col-md-6">
                    <div id="myChartFF_MedioTransporte">
                        
                    </div>	
                </div>
            </div>
        </div>
    </div>

   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra_js'); ?>

    <script>
        $(document).on('select2:open', () => {
            document.querySelector('.select2-search__field').focus();
        });
    </script>
    <script src="../../../src/js/scripts/pages_app/cuadro_resumen.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\alex.vasquez\Desktop\Archivos\Files\ProyectosLaravel\ProyectoMalariaJunin\resources\views/CuadrosResumen.blade.php ENDPATH**/ ?>